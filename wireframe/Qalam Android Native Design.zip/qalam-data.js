// Qalam seed data — Arabic vocabulary, roots, and texts.
// Mastery: 0 unseen · 1 learning · 2 reviewing · 3 mastered
export const data = {
  words: [
    { id: "kataba", ar: "كَتَبَ", tr: "kataba", gloss: "to write", pos: "verb", dialect: "MSA", root: "ktb", mastery: 3,
      examples: [
        { ar: "كَتَبَ الرِّسالةَ بِخَطٍّ جَميل.", tr: "kataba r-risālata bi-khaṭṭin jamīl", en: "He wrote the letter in beautiful handwriting." },
        { ar: "أَكْتُبُ في دَفْتَري كُلَّ يَوم.", tr: "aktubu fī daftarī kulla yawm", en: "I write in my notebook every day." }
      ],
      dict: [ { name: "Almaany", host: "almaany.com" }, { name: "Wiktionary", host: "wiktionary.org" }, { name: "Living Arabic", host: "livingarabic.com" } ] },
    { id: "kitab", ar: "كِتاب", tr: "kitāb", gloss: "book", pos: "noun · m.", dialect: "MSA", root: "ktb", mastery: 2,
      examples: [
        { ar: "قَرَأْتُ الكِتابَ مَرَّتَيْن.", tr: "qaraʾtu l-kitāba marratayn", en: "I read the book twice." }
      ],
      dict: [ { name: "Almaany", host: "almaany.com" }, { name: "Reverso", host: "reverso.net" } ] },
    { id: "maktab", ar: "مَكْتَب", tr: "maktab", gloss: "office, desk", pos: "noun · m.", dialect: "MSA", root: "ktb", mastery: 1,
      examples: [ { ar: "هُوَ في المَكْتَبِ الآن.", tr: "huwa fī l-maktabi l-ān", en: "He is in the office now." } ],
      dict: [ { name: "Almaany", host: "almaany.com" } ] },
    { id: "maktaba", ar: "مَكْتَبة", tr: "maktaba", gloss: "library, bookshop", pos: "noun · f.", dialect: "MSA", root: "ktb", mastery: 1,
      examples: [ { ar: "المَكْتَبةُ مَفْتوحةٌ حَتّى المَساء.", tr: "al-maktabatu maftūḥatun ḥattā l-masāʾ", en: "The library is open until evening." } ],
      dict: [ { name: "Almaany", host: "almaany.com" }, { name: "Wiktionary", host: "wiktionary.org" } ] },
    { id: "katib", ar: "كاتِب", tr: "kātib", gloss: "writer, clerk", pos: "noun · m.", dialect: "MSA", root: "ktb", mastery: 2,
      examples: [ { ar: "هُوَ كاتِبٌ مَشْهور.", tr: "huwa kātibun mashhūr", en: "He is a famous writer." } ],
      dict: [ { name: "Almaany", host: "almaany.com" } ] },
    { id: "darasa", ar: "دَرَسَ", tr: "darasa", gloss: "to study", pos: "verb", dialect: "MSA", root: "drs", mastery: 2,
      examples: [ { ar: "دَرَسَ العَرَبِيّةَ سَنَتَيْن.", tr: "darasa l-ʿarabiyyata sanatayn", en: "He studied Arabic for two years." } ],
      dict: [ { name: "Almaany", host: "almaany.com" }, { name: "Living Arabic", host: "livingarabic.com" } ] },
    { id: "madrasa", ar: "مَدْرَسة", tr: "madrasa", gloss: "school", pos: "noun · f.", dialect: "MSA", root: "drs", mastery: 3,
      examples: [ { ar: "تَقَعُ المَدْرَسةُ قُرْبَ البَيت.", tr: "taqaʿu l-madrasatu qurba l-bayt", en: "The school is near the house." } ],
      dict: [ { name: "Almaany", host: "almaany.com" }, { name: "Wiktionary", host: "wiktionary.org" } ] },
    { id: "dars", ar: "دَرْس", tr: "dars", gloss: "lesson", pos: "noun · m.", dialect: "MSA", root: "drs", mastery: 1,
      examples: [ { ar: "الدَّرْسُ الأوَّلُ سَهْل.", tr: "ad-darsu l-awwalu sahl", en: "The first lesson is easy." } ],
      dict: [ { name: "Almaany", host: "almaany.com" } ] },
    { id: "alima", ar: "عَلِمَ", tr: "ʿalima", gloss: "to know", pos: "verb", dialect: "MSA", root: "alm", mastery: 2,
      examples: [ { ar: "عَلِمْتُ بِالخَبَرِ أَمْس.", tr: "ʿalimtu bi-l-khabari ams", en: "I learned of the news yesterday." } ],
      dict: [ { name: "Almaany", host: "almaany.com" }, { name: "Reverso", host: "reverso.net" } ] },
    { id: "ilm", ar: "عِلْم", tr: "ʿilm", gloss: "knowledge, science", pos: "noun · m.", dialect: "MSA", root: "alm", mastery: 1,
      examples: [ { ar: "العِلْمُ نور.", tr: "al-ʿilmu nūr", en: "Knowledge is light." } ],
      dict: [ { name: "Almaany", host: "almaany.com" } ] },
    { id: "muallim", ar: "مُعَلِّم", tr: "muʿallim", gloss: "teacher", pos: "noun · m.", dialect: "MSA", root: "alm", mastery: 0,
      examples: [ { ar: "المُعَلِّمُ صَبور.", tr: "al-muʿallimu ṣabūr", en: "The teacher is patient." } ],
      dict: [ { name: "Almaany", host: "almaany.com" } ] },
    { id: "salam", ar: "سَلام", tr: "salām", gloss: "peace", pos: "noun · m.", dialect: "MSA", root: "slm", mastery: 3,
      examples: [ { ar: "السَّلامُ عَلَيْكُم.", tr: "as-salāmu ʿalaykum", en: "Peace be upon you." } ],
      dict: [ { name: "Almaany", host: "almaany.com" }, { name: "Wiktionary", host: "wiktionary.org" } ] }
  ],
  roots: [
    { id: "ktb", ar: "ك · ت · ب", letters: "ك ت ب", tr: "k–t–b", meaning: "writing, recording",
      note: "The root ك-ت-ب gathers everything bound up with the act of writing. From the bare verb kataba (\"he wrote\") the language fans out: the thing written (kitāb, a book), the place of writing (maktab, an office; maktaba, a library), and the one who writes (kātib). The passive participle maktūb — \"written\" — carries a fatalistic shade in everyday speech: what is written, i.e. destined.",
      forms: [
        { ar: "كَتَبَ", tr: "kataba", gloss: "to write", wordId: "kataba" },
        { ar: "كِتاب", tr: "kitāb", gloss: "book", wordId: "kitab" },
        { ar: "مَكْتَب", tr: "maktab", gloss: "office", wordId: "maktab" },
        { ar: "مَكْتَبة", tr: "maktaba", gloss: "library", wordId: "maktaba" },
        { ar: "كاتِب", tr: "kātib", gloss: "writer", wordId: "katib" },
        { ar: "مَكْتوب", tr: "maktūb", gloss: "written; fate", wordId: null }
      ] },
    { id: "drs", ar: "د · ر · س", letters: "د ر س", tr: "d–r–s", meaning: "studying, learning",
      note: "د-ر-س turns on careful, repeated study. The verb darasa is \"to study\"; intensified to darrasa it becomes \"to teach.\" The place where this happens is the madrasa — literally \"a place of study\" — and a single unit of it is a dars, a lesson.",
      forms: [
        { ar: "دَرَسَ", tr: "darasa", gloss: "to study", wordId: "darasa" },
        { ar: "دَرْس", tr: "dars", gloss: "lesson", wordId: "dars" },
        { ar: "مَدْرَسة", tr: "madrasa", gloss: "school", wordId: "madrasa" },
        { ar: "مُدَرِّس", tr: "mudarris", gloss: "teacher", wordId: null },
        { ar: "دِراسة", tr: "dirāsa", gloss: "study", wordId: null }
      ] },
    { id: "alm", ar: "ع · ل · م", letters: "ع ل م", tr: "ʿ–l–m", meaning: "knowing",
      note: "ع-ل-م is the field of knowing. ʿalima is \"to know\"; ʿilm is knowledge and, by extension, science. The teacher (muʿallim) is one who makes another know, and a scholar (ʿālim) is one steeped in knowledge. Strikingly, the same letters give ʿālam — \"world\" — the known whole.",
      forms: [
        { ar: "عَلِمَ", tr: "ʿalima", gloss: "to know", wordId: "alima" },
        { ar: "عِلْم", tr: "ʿilm", gloss: "knowledge", wordId: "ilm" },
        { ar: "مُعَلِّم", tr: "muʿallim", gloss: "teacher", wordId: "muallim" },
        { ar: "عالِم", tr: "ʿālim", gloss: "scholar", wordId: null },
        { ar: "عالَم", tr: "ʿālam", gloss: "world", wordId: null }
      ] },
    { id: "slm", ar: "س · ل · م", letters: "س ل م", tr: "s–l–m", meaning: "soundness, peace",
      note: "س-ل-م centres on being whole, safe, and at peace. From it come salām (peace), the greeting as-salāmu ʿalaykum, and the religiously loaded islām — \"submission\" that brings peace — alongside muslim, the one who submits.",
      forms: [
        { ar: "سَلام", tr: "salām", gloss: "peace", wordId: "salam" },
        { ar: "إِسْلام", tr: "islām", gloss: "submission", wordId: null },
        { ar: "مُسْلِم", tr: "muslim", gloss: "muslim", wordId: null },
        { ar: "سالِم", tr: "sālim", gloss: "safe, sound", wordId: null }
      ] }
  ],
  texts: [
    { id: "school", title: "Going to school", titleAr: "الذَّهابُ إلى المَدْرَسة", dialect: "MSA", difficulty: "Beginner", source: "Composed",
      translation: "The diligent student went to school early in the morning to study his Arabic lesson.",
      tokens: [
        { ar: "ذَهَبَ", tr: "dhahaba", gloss: "went", wordId: null },
        { ar: "الطّالِبُ", tr: "aṭ-ṭālibu", gloss: "the-student", wordId: null },
        { ar: "المُجْتَهِدُ", tr: "al-mujtahidu", gloss: "the-diligent", wordId: null },
        { ar: "إلى", tr: "ilā", gloss: "to", wordId: null },
        { ar: "المَدْرَسةِ", tr: "al-madrasati", gloss: "the-school", wordId: "madrasa" },
        { ar: "صَباحًا", tr: "ṣabāḥan", gloss: "in-morning", wordId: null },
        { ar: "لِيَدْرُسَ", tr: "li-yadrusa", gloss: "to-study", wordId: "darasa" },
        { ar: "دَرْسَ", tr: "darsa", gloss: "lesson-of", wordId: "dars" },
        { ar: "العَرَبِيّةِ", tr: "al-ʿarabiyyati", gloss: "the-Arabic", wordId: null }
      ] },
    { id: "peace", title: "A greeting", titleAr: "تَحِيّة", dialect: "MSA", difficulty: "Beginner", source: "Composed",
      translation: "Peace be upon you. And upon you peace. How are you, my friend?",
      tokens: [
        { ar: "السَّلامُ", tr: "as-salāmu", gloss: "the-peace", wordId: "salam" },
        { ar: "عَلَيْكُم", tr: "ʿalaykum", gloss: "upon-you", wordId: null },
        { ar: "وَعَلَيْكُمُ", tr: "wa-ʿalaykumu", gloss: "and-upon-you", wordId: null },
        { ar: "السَّلام", tr: "as-salām", gloss: "the-peace", wordId: "salam" },
        { ar: "كَيْفَ", tr: "kayfa", gloss: "how", wordId: null },
        { ar: "حالُكَ", tr: "ḥāluka", gloss: "your-state", wordId: null },
        { ar: "يا", tr: "yā", gloss: "O", wordId: null },
        { ar: "صَديقي", tr: "ṣadīqī", gloss: "my-friend", wordId: null }
      ] },
    { id: "knowledge", title: "Knowledge is light", titleAr: "العِلْمُ نور", dialect: "MSA", difficulty: "Intermediate", source: "Proverb",
      translation: "Knowledge is light, and the teacher lights the path of the student toward it.",
      tokens: [
        { ar: "العِلْمُ", tr: "al-ʿilmu", gloss: "the-knowledge", wordId: "ilm" },
        { ar: "نورٌ", tr: "nūrun", gloss: "light", wordId: null },
        { ar: "وَالمُعَلِّمُ", tr: "wa-l-muʿallimu", gloss: "and-the-teacher", wordId: "muallim" },
        { ar: "يُنيرُ", tr: "yunīru", gloss: "lights", wordId: null },
        { ar: "طَريقَ", tr: "ṭarīqa", gloss: "path-of", wordId: null },
        { ar: "الطّالِبِ", tr: "aṭ-ṭālibi", gloss: "the-student", wordId: null },
        { ar: "إلَيْهِ", tr: "ilayhi", gloss: "toward-it", wordId: null }
      ] }
  ]
};
export default data;
